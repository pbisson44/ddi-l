﻿ddi-l metadata tables

One CSV file per table. Fill the rows, then load them with
ddi_l.tables.load_tables('this-folder') or `ddi tables import`.
Full guide: https://pbisson44.github.io/ddi-l/latest/spreadsheet-import/


settings.csv: One row per setting, in two columns: `setting` and `value`.
  setting (required): agency, version or language.
  value (required): The setting's value.

studies.csv: One row per study (a survey cycle, a census, an administrative source).
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  title@<language>  (e.g. title@en, title@fr): The study's title.
  subtitle@<language>  (e.g. subtitle@en, subtitle@fr): A subtitle.
  alternate_title@<language>  (e.g. alternate_title@en, alternate_title@fr): Another title, such as an acronym.
  abstract@<language>  (e.g. abstract@en, abstract@fr): What the study is about.
  purpose@<language>  (e.g. purpose@en, purpose@fr): Why it was done.
  creator: Who made it: ids in `organizations` or `individuals`, or names.
  publisher: Who publishes it: ids in `organizations` or `individuals`, or names.
  publication_date: When it was published: 2024, 2024-05, 2024-05-31.
  kind_of_data: Survey data, administrative records...
  analysis_unit: Persons, households, businesses...
  universe: Who the study covers (an `id` in `universes`).
  concept: The concept that defines the study (an `id` in `concepts`).
  keywords@<language>  (e.g. keywords@en, keywords@fr): Topics, separated by |.
  start_date: Start of the period covered: 2024-01-01.
  end_date: End of the period covered: 2024-12-31.
  countries: ISO country codes covered: CA|US.
  funder: Who funds it (ids in `organizations`).
  grant_number: The funding grant's number.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

groups.csv: One row per group of studies, such as all cycles of a survey.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  title@<language>  (e.g. title@en, title@fr): The group's title.
  abstract@<language>  (e.g. abstract@en, abstract@fr): What the group holds.
  purpose@<language>  (e.g. purpose@en, purpose@fr): Why the studies are grouped.
  type: The kind of group: Series, Program...
  studies: The studies in it (ids in `studies`).
  parent: The group it sits in (an `id` in `groups`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

organizations.csv: One row per organization: creators, publishers, funders.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name@<language>  (e.g. name@en, name@fr) (required): The organization's name.
  abbreviation: A short name: StatCan.
  email: A contact email address.
  url: Its web site.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

individuals.csv: One row per person.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  first_name: Given name.
  last_name: Family name.
  email: A contact email address.
  url: A web page.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

concepts.csv: What is measured: one row per concept.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  parent: The broader concept(s) this one narrows (ids in `concepts`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

universes.csv: Who or what is described: one row per universe.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  concept: The concept that defines the universe (an `id` in `concepts`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

unit_types.csv: One row per kind of unit: person, household, business.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  concept: The concept it measures (an `id` in `concepts`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

conceptual_variables.csv: One row per conceptual variable: a concept measured on a unit type, with no representation yet.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  concept: The concept it measures (an `id` in `concepts`).
  universe: Who it describes (ids in `universes`).
  unit_type: The kind of unit it describes (an `id` in `unit_types`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

represented_variables.csv: One row per represented variable: a conceptual variable with a representation, shared by the variables that record it the same way.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  conceptual_variable: The conceptual variable it represents (an `id` in `conceptual_variables`).
  concept: The concept it measures (an `id` in `concepts`).
  unit_type: The kind of unit it describes (an `id` in `unit_types`).
  representation: How values are recorded: code, numeric, text or datetime.
  code_list: For `code`: the code list (an `id` in `code_lists`).
  numeric_type: For `numeric`: Integer, Decimal, Float, Double, Long or Short.
  min: For `numeric`: the lowest valid value.
  max: For `numeric`: the highest valid value.
  max_length: For `text`: the longest valid answer, in characters.
  date_type: For `datetime`: Date, DateTime, Time, Year, YearMonth or Duration.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

code_lists.csv: One row per code list. The codes themselves go in `codes`.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

codes.csv: One row per code, in display order. Each code gets a category holding its labels.
  code_list (required): The code list the code belongs to (an `id` in `code_lists`).
  value (required): The code as stored in the data: 1, 01, M. Format the column as text in Excel so 01 keeps its zero.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  category: Optional key to share one category between code lists: codes with the same `category` point to one category, labelled from the first of them.
  missing: true for a missing-value code (Refusal, Don't know).
  parent: For a hierarchy (a classification): the `value` of the code this one sits under, in the same code list. The parent's row comes first.

instructions.csv: One row per instruction to respondents or interviewers, attached to questions with their `instruction` column.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  text@<language>  (e.g. text@en, text@fr): The instruction.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

questions.csv: One row per question.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  text@<language>  (e.g. text@en, text@fr): The question as asked. For wording that differs by audience (proxy, interviewer), add rows to `question_texts`.
  concept: The concept the question measures (an `id` in `concepts`).
  response: The kind of answer: code, numeric, text or datetime. Empty for no response domain.
  code_list: For `code`: the code list (an `id` in `code_lists`).
  numeric_type: For `numeric`: Integer, Decimal, Float, Double, Long or Short.
  min: For `numeric`: the lowest valid value.
  max: For `numeric`: the highest valid value.
  max_length: For `text`: the longest valid answer, in characters.
  date_type: For `datetime`: Date, DateTime, Time, Year, YearMonth or Duration.
  instruction: Instructions shown with it (ids in `instructions`).
  group: The question group(s) it belongs to (ids in `question_groups`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

question_texts.csv: Extra wordings of a question, one row per language and audience. Use it when one question is worded differently for different audiences.
  question (required): The question (an `id` in `questions`).
  language (required): The wording's language: en, fr-CA.
  audience: Who the wording is for: proxy, intvwr, self-resp. Letters and digits, at most 8 between hyphens. Empty for everyone.
  text (required): The wording.

question_grids.csv: One row per grid question: rows from one code list, optional columns from another, one response for each cell.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  text@<language>  (e.g. text@en, text@fr): The question as asked.
  concept: The concept it measures (an `id` in `concepts`).
  rows: The grid's rows (an `id` in `code_lists`).
  columns: The grid's columns, if any (an `id` in `code_lists`).
  response: The answer in each cell: code, numeric, text or datetime.
  code_list: For `code`: the code list (an `id` in `code_lists`).
  numeric_type: For `numeric`: Integer, Decimal, Float, Double, Long or Short.
  min: For `numeric`: the lowest valid value.
  max: For `numeric`: the highest valid value.
  max_length: For `text`: the longest valid answer, in characters.
  date_type: For `datetime`: Date, DateTime, Time, Year, YearMonth or Duration.
  instruction: Instructions shown with it (ids in `instructions`).
  group: The question group(s) it belongs to (ids in `question_groups`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

question_blocks.csv: One row per block of questions presented together.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  intent@<language>  (e.g. intent@en, intent@fr): What the block is for.
  questions: Its questions, in order: ids in `questions` or `question_grids`.
  concept: The concept it measures (an `id` in `concepts`).
  instruction: Instructions shown with it (ids in `instructions`).
  group: The question group(s) it belongs to (ids in `question_groups`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

question_groups.csv: One row per question group, such as a module of a questionnaire. Questions join with their `group` column.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  type: The kind of group: Module, Topic...
  parent: The group it sits in (an `id` in `question_groups`).
  concept: The concept it measures (an `id` in `concepts`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

instruments.csv: One row per questionnaire (instrument). Its content is in `flow`.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  study: The study it belongs to (an `id` in `studies`). Empty for the only study, when `studies` has one row.
  type: The kind of instrument: CAWI, CATI, Paper...
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

flow.csv: The questionnaire flow: one row per step, in order. Steps nest under a sequence, condition or loop through `parent`.
  instrument (required): The instrument (an `id` in `instruments`).
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  type (required): question, statement, sequence, if or loop.
  parent: The sequence, if or loop it is inside (an `id` in `flow`).
  branch: Inside an if: then or else. Defaults to then.
  question: For question: an id in `questions`, `question_grids` or `question_blocks`.
  text@<language>  (e.g. text@en, text@fr): For statement: the text shown.
  condition: For if and loop: the condition, such as AGE >= 15.
  condition_language: The language the condition is written in. Defaults to pseudo-code.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

variables.csv: One row per variable (column of your data file).
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  concept: The concept the variable measures (an `id` in `concepts`).
  universe: Who the variable describes (ids in `universes`).
  question: The question(s) the variable's values come from (ids in `questions`).
  representation: How the values are recorded: code, numeric, text or datetime. Empty to take the response of its represented variable, or of its first question.
  code_list: For `code`: the code list (an `id` in `code_lists`).
  numeric_type: For `numeric`: Integer, Decimal, Float, Double, Long or Short.
  min: For `numeric`: the lowest valid value.
  max: For `numeric`: the highest valid value.
  max_length: For `text`: the longest valid answer, in characters.
  date_type: For `datetime`: Date, DateTime, Time, Year, YearMonth or Duration.
  unit_type: The kind of unit it describes (an `id` in `unit_types`).
  conceptual_variable: Its conceptual variable (an `id` in `conceptual_variables`).
  represented_variable: Its represented variable (an `id` in `represented_variables`).
  dataset: The data file(s) it is a column of (ids in `datasets`), in column order.
  group: The variable group(s) it belongs to (ids in `variable_groups`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

variable_groups.csv: One row per variable group, such as a topic or derived-variable set. Variables join with their `group` column.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  type: The kind of group: Topic, Derived...
  parent: The group it sits in (an `id` in `variable_groups`).
  concept: The concept it measures (an `id` in `concepts`).
  universe: Who it describes (ids in `universes`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

datasets.csv: One row per data file. Variables join with their `dataset` column. The `label` and `description` describe the file's record of variables.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  title@<language>  (e.g. title@en, title@fr): The file's title. Defaults to `name`.
  file: Where the file is: a path or URL.
  study: The study it belongs to (an `id` in `studies`). Empty for the only study, when `studies` has one row.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

ncubes.csv: One row per n-cube (a multidimensional table of aggregates).
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  dimensions: Its dimensions, in order: ids in `variables`.
  purpose@<language>  (e.g. purpose@en, purpose@fr): What the n-cube is for.
  universe: Who it describes (ids in `universes`).
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

methodologies.csv: How a study's data were collected: one row per methodology.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  study: The study it belongs to (an `id` in `studies`). Empty for the only study, when `studies` has one row.
  data_collection@<language>  (e.g. data_collection@en, data_collection@fr): How data were collected.
  time_method@<language>  (e.g. time_method@en, time_method@fr): Cross-section, panel, time series...
  sampling@<language>  (e.g. sampling@en, sampling@fr): How the sample was drawn.
  deviation@<language>  (e.g. deviation@en, deviation@fr): How the sample departs from its design.
  weighting@<language>  (e.g. weighting@en, weighting@fr): How weights were derived.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

processing_events.csv: What was done to a study's data after collection: one row per event.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  study: The study it belongs to (an `id` in `studies`). Empty for the only study, when `studies` has one row.
  control@<language>  (e.g. control@en, control@fr): Checks made on the data.
  cleaning@<language>  (e.g. cleaning@en, cleaning@fr): How the data were cleaned or edited.
  weighting@<language>  (e.g. weighting@en, weighting@fr): How the data were weighted.
  appraisal@<language>  (e.g. appraisal@en, appraisal@fr): Response rates, sampling error...
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

quality_statements.csv: One row per statement about a study's quality.
  id (required): Your key for the row, unique in this table. Other tables use it to point here. Any text without spaces works: AGE, Q_AGE, 101.
  ddi_id: The DDI identifier (a UUID) to give the item. Leave empty and one is derived from the agency, the table and `id`, so loading the same tables again gives the same identifiers. Fill it to update an item that already exists in Colectica.
  version: The item's version. Defaults to `version` in `settings`.
  name: The item's name, in the `settings` language. Defaults to `id`.
  label@<language>  (e.g. label@en, label@fr): A short human-readable label.
  description@<language>  (e.g. description@en, description@fr): A longer description or definition.
  study: The study it belongs to (an `id` in `studies`). Empty for the only study, when `studies` has one row.
  text@<language>  (e.g. text@en, text@fr): The statement.
  custom:<name>: Any property of your own, one column per property. Stored as r:UserAttributePair with key extension:<name>.

comparisons.csv: How items compare, across studies or cycles: one row per pair. Rows with the same `map` form one map.
  map (required): Your key for the map the row belongs to.
  type (required): What is compared: concept, universe, question, variable or category.
  source (required): The item compared from (its id in that table).
  target (required): The item compared to (its id in that table).
  commonality@<language>  (e.g. commonality@en, commonality@fr): What they share.
  difference@<language>  (e.g. difference@en, difference@fr): How they differ.
  weight: How alike they are, from 0 to 1.

settings.csv: Rows: agency (required): The maintenance agency of every item, such as ca.statcan.; version (default 1): The version of every item without its own.; language (default en): The language of names (the `name` column), such as en or fr-CA.

(all).csv: Several ids in one cell are separated by |. Columns starting with # or _ are notes and are ignored.
